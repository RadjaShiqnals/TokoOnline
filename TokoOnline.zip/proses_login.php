<?php 
    if($_POST){
        $loginid=$_POST['loginid'];
        $loginpassword=$_POST['loginpassword'];
        if(empty($loginid)){
            echo "<script>alert('Login tidak boleh kosong');location.href='login.php';</script>";
        } elseif(empty($loginpassword)){
            echo "<script>alert('Password tidak boleh kosong');location.href='login.php';</script>";
        } else {
            include "koneksi.php";
            $qry_login=mysqli_query($conn,"SELECT * from user where login = '".$loginid."' and password = '".$loginpassword."'");
            if(mysqli_num_rows($qry_login)>0){
                $dt_login=mysqli_fetch_array($qry_login);
                session_start();
                $_SESSION['id_user']=$dt_login['id_user'];
                $_SESSION['username']=$dt_login['username'];
                $_SESSION['status_login_tokoonline']=true;
                header("location: home.php");
            } else {
                echo "<script>alert('Login dan Password tidak benar');location.href='login.php';</script>";
            }
        }
    }
?>
