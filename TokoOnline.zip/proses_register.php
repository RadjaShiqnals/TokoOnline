<?php 
if ($_POST) {
    $username = $_POST['username'];
    $loginid = $_POST['loginid'];
    $loginpassword = $_POST['loginpassword'];
    if (empty($loginid)) {
        echo "<script>alert('login tidak boleh kosong');location.href='register.php';</script>";

    }
    elseif (empty($username)) {
        echo "<script>alert('username tidak boleh kosong');location.href='register.php';</script>";
    }
    elseif (empty($loginpassword)) {
        echo "<script>alert('password tidak boleh kosong');location.href='register.php';</script>";
    } else {
    include 'koneksi.php';
        $insert =mysqli_query($conn, "INSERT INTO user (username, login, password) VALUE ('".$username."','".$loginid."', '".$loginpassword."')");
        if($insert){
            echo "<script>alert('Sukses menambahkan Akun');location.href='register.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan Akun');location.href='register.php';</script>";
        }
    }
}
?>