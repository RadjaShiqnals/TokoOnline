<?php
session_start();
if ($_SESSION['status_login_tokoonline'] != true) {
    header('location: home.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom bg-white text-dark navbar nav fixed-top shadow-lg">
        <ul class="nav nav-pills">
            <li class="nav-item"><a href="home.php" class="nav-link" aria-current="page">Home</a></li>
            <li class="nav-item"><a href="belanja.php" class="nav-link">Toko</a></li>
            <li class="nav-item"><a href="transaksi.php" class="nav-link">Transaksi</a></li>
            <li class="nav-item"><a href="logout.php" class="nav-link">Logout</a></li>
            <li class="nav-item"><a href="assets/about.html" class="nav-link">About Us</a></li>
        </ul>
    </header>