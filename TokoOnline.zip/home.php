<?php 
include "header.php";
?>
<h1 style="text-align: center;margin-top:100px;">Selamat datang <?=$_SESSION['username']?> di Toko Online.</h1>
<div class="center  ">
            <button type="button" class="btn btn-outline-primary btn-lg px-4" onclick="window.location.href='about_us.html'">About us</button> 
          </div>
<?php 
include "footer.php";
?>